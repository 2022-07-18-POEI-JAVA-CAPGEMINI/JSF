package com.webstart.listanddemo;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

@ManagedBean
@ApplicationScoped
public class StudentData {
	
	private List<Student> students;
	
	public StudentData() {
		loadSampleData();
	}

	public void loadSampleData() {
		
		students = new ArrayList<>();
		students.add(new Student("Samih", "Habbani", "contact@mail.com"));
		students.add(new Student("Tom", "Ford", "contact21@mail.com"));
		students.add(new Student("Nicolas", "Valontino", "team@mail.com"));
	}
	
	public List<Student> getStudents() {
		return students;
	}
}
