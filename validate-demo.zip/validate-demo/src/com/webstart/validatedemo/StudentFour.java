package com.webstart.validatedemo;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

@ManagedBean
public class StudentFour {

	private String firstName;
	private String lastName;
	private String email;
	private String postalCode;
	private int age;
	private String phone;
	private String courseCode;
	
	public StudentFour() {
		
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
	
	
	// Méthode de controle
	// FacesContext" pour représenter les informations contextuelles associées au traitement d'une requête et à la production de la réponse correspondante.
	// Cette classe permet d'interagir avec l'interface utilisateur et le reste de l'environnement JSF
	// UIComponent component : the field
	// Object Value : the value of the field
	public void validateTheCourseCode(FacesContext context,
			UIComponent component,
			Object value) throws ValidatorException {
		
		if (value == null) {
			return;
		}
		
		String data = value.toString();
		
		if(!data.startsWith("ACADEMIE_WS_")) {
			
			// FacesMessage represents a single validation (or other) message, 
			// which is typically associated with a particular component in the view.
			FacesMessage message = new FacesMessage("Votre cours ne commence pas par ACADEMIE_WS_");
			throw new ValidatorException(message);
		}
		
	}
	
	
}
