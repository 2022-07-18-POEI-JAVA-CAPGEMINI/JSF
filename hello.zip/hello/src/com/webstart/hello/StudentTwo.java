package com.webstart.hello;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class StudentTwo {
	
	private String firstName;
	private String lastName;
	private String city;
	
	// A ne faire que quand je parle de comment pré-charger les données avec mon managed bean
	private List<String> cities;
	
	public StudentTwo() {
		
		cities = new ArrayList<>();
		cities.add("Casablanca");
		cities.add("Rabat");
		cities.add("Fes");
		cities.add("Berkane");
		
	}
	
	public List<String> getCities() {
		return cities;
	}
	

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	
	
	

}
